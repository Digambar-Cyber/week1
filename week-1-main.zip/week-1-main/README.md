# week-1
this project to develop a CNN-based system for early detection and classification of plant diseases using leaf image to support precision agriculture . 
